package com.claudecompanion;

import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod("claudecompanion")
public class ClaudeCompanionMod {
    public ClaudeCompanionMod() {
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, Config.SPEC);
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModEntities.ENTITIES.register(modBus);
        modBus.addListener(this::onAttributes);
        MinecraftForge.EVENT_BUS.register(this);
    }

    private void onAttributes(EntityAttributeCreationEvent e) {
        e.put(ModEntities.CLAUDE.get(), ClaudeEntity.createAttributes().build());
    }

    @SubscribeEvent
    public void onCommands(RegisterCommandsEvent e) {
        ClaudeCommand.register(e.getDispatcher());
    }

    // También puedes escribir en el chat: "@claude ¿qué hago ahora?"
    @SubscribeEvent
    public void onChat(ServerChatEvent e) {
        String msg = e.getRawText();
        if (msg.regionMatches(true, 0, "@claude", 0, 7)) {
            ServerPlayer p = e.getPlayer();
            ClaudeCommand.ask(p, msg.substring(7).trim());
        }
    }
}
